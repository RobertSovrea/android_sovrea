package com.example.myjournallapp2.utils;

public class Constants {
    public static final String BASE_URL = "https://yourapi.com/";
    // Alte constante
}
